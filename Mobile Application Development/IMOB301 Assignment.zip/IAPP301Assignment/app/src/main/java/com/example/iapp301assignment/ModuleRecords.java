package com.example.iapp301assignment;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.Date;

public class ModuleRecords extends AppCompatActivity {
    private EditText editTextName, editTextModuleDuration;
    private Button addModule, viewModule;
    private MyDatabaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_module_records);

        editTextName = findViewById(R.id.txtModulename);
        editTextModuleDuration = findViewById(R.id.txtModuleduration);
        addModule = (Button) findViewById(R.id.btnAddmodule);
        viewModule=(Button) findViewById(R.id.btnViewmodule);

        myDb = new MyDatabaseHelper(this);

        addModule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String name = editTextName.getText().toString();

                int duration = Integer.parseInt(editTextModuleDuration.getText().toString());


                boolean isInserted = myDb.insertData3(name, duration);
                if (isInserted) {
                    Toast.makeText(ModuleRecords.this, "Module Data Added!", Toast.LENGTH_LONG).show();
                    editTextName.setText("");
                    editTextModuleDuration.setText("");

                } else {
                    Toast.makeText(ModuleRecords.this, "Module Data Not Added", Toast.LENGTH_LONG).show();
                }
            }
        });
        viewModule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res =myDb.getAllItems3();
                if(res.getCount()==0)
                {
                    Toast.makeText(ModuleRecords.this, "Nothing found", Toast.LENGTH_LONG).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext()){
                    buffer.append("ID :"+res.getString(0)+"\n");
                    buffer.append("Name :"+res.getString(1)+"\n");
                    buffer.append("Duration :"+res.getString(2)+"\n\n");

                }
                AlertDialog.Builder builder = new AlertDialog.Builder(ModuleRecords.this);
                builder.setCancelable(true);
                builder.setTitle("Modules");
                builder.setMessage(buffer.toString());
                builder.show();

            }
        });
    }
}
