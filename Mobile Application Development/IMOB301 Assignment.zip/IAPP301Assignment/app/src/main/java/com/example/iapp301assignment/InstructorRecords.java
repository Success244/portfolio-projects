package com.example.iapp301assignment;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class InstructorRecords extends AppCompatActivity {
    private EditText editTextName, editTextSurname, editTextPassword;
    private Button addInstructor, viewInstructors;
    private MyDatabaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructor_records);

        editTextName = findViewById(R.id.txtNameInstructor);
        editTextSurname = findViewById(R.id.txtSurnameInstructor);
        editTextPassword = findViewById(R.id.txtInstructorPassword);
        addInstructor = (Button) findViewById(R.id.btnAddInstructor);
        viewInstructors = (Button) findViewById(R.id.btnViewInstructors);
        myDb = new MyDatabaseHelper(this);
        addInstructor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = editTextName.getText().toString();

                String surname = (editTextSurname.getText().toString());
                String password = (editTextPassword.getText().toString());


                boolean isInserted = myDb.insertData4(name, surname, password);
                if (isInserted) {
                    Toast.makeText(InstructorRecords.this, "Instructor Data Added!", Toast.LENGTH_LONG).show();
                    editTextName.setText("");
                    editTextSurname.setText("");
                    editTextPassword.setText("");

                } else {
                    Toast.makeText(InstructorRecords.this, "Instructor Data Not Added", Toast.LENGTH_LONG).show();
                }

            }
        });
        viewInstructors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = myDb.getAllItems4();
                if(res.getCount()==0)
                {
                    Toast.makeText(InstructorRecords.this, "Nothing found", Toast.LENGTH_LONG).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext()){
                    buffer.append("ID :"+res.getString(0)+"\n");
                    buffer.append("Name :"+res.getString(1)+"\n");
                    buffer.append("Surname :"+res.getString(2)+"\n");
                    buffer.append("Password :"+res.getString(3)+"\n\n");

                }
                AlertDialog.Builder builder = new AlertDialog.Builder(InstructorRecords.this);
                builder.setCancelable(true);
                builder.setTitle("Instructors");
                builder.setMessage(buffer.toString());
                builder.show();

            }
        });
    }
}
