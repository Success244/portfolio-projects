package com.example.iapp301assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Student extends AppCompatActivity {
    private MyDatabaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);

        myDb = new MyDatabaseHelper(this);

        Button availabletask = findViewById(R.id.btnAvailableTask);
        LinearLayout taskContainer = findViewById(R.id.taskContainer);

        availabletask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                taskContainer.removeAllViews(); // Clear previous entries

                Cursor res = myDb.getAllItems();
                if (res.getCount() == 0) {
                    Toast.makeText(Student.this, "No tasks found", Toast.LENGTH_LONG).show();
                    return;
                }

                while (res.moveToNext()) {
                    String name = res.getString(1);
                    String date = res.getString(2);
                    String module = res.getString(3);

                    LinearLayout singleTaskLayout = new LinearLayout(Student.this);
                    singleTaskLayout.setOrientation(LinearLayout.VERTICAL);
                    singleTaskLayout.setPadding(16, 16, 16, 16);
                    singleTaskLayout.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);

                    TextView text = new TextView(Student.this);
                    text.setText("Name: " + name + "\nDue Date: " + date + "\nModule: " + module);
                    text.setTextSize(16);

                    CheckBox checkBox = new CheckBox(Student.this);
                    checkBox.setText("Mark as Completed");

                    checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
                        if (isChecked) {
                            text.setPaintFlags(text.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                        } else {
                            text.setPaintFlags(text.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
                        }
                    });

                    singleTaskLayout.addView(text);
                    singleTaskLayout.addView(checkBox);
                    taskContainer.addView(singleTaskLayout);
                }
            }
        });
    }
}
