package com.example.iapp301assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.Date;

public class Module extends AppCompatActivity {
    private EditText editTextModuleName, editTextModuleDuration;
    private Button AddModule, ViewModule;
    private MyDatabaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_module);
        editTextModuleName = (EditText) findViewById(R.id.txtModuleName);
        editTextModuleDuration = (EditText) findViewById(R.id.txtModuleDuration);
        AddModule = (Button) findViewById(R.id.btnAddModule);
        ViewModule = (Button) findViewById(R.id.btnViewModule);
        AddModule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = editTextModuleName.getText().toString();

                int duration = Integer.parseInt(editTextModuleDuration.getText().toString());
                boolean isInserted = myDb.insertData3(name, duration);
                if (isInserted) {
                    Toast.makeText(Module.this, "Data inserted", Toast.LENGTH_LONG).show();
                    editTextModuleName.setText("");
                    editTextModuleDuration.setText("");

                } else {
                    Toast.makeText(Module.this, "Data not inserted", Toast.LENGTH_LONG).show();
                }


            }
        });
        ViewModule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor cursor3= myDb.getAllItems3();
                if (cursor3.getCount()==0){
                    Toast.makeText(Module.this, "Nothing found", Toast.LENGTH_LONG).show();
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while(cursor3.moveToNext()) {
                    buffer.append("ID:"+cursor3.getString(0) +"\n" );
                    buffer.append("Module Name:"+ cursor3.getString(1) +"\n");
                    buffer.append("Module duration:"+cursor3.getString(2)+"\n");
                }
                Toast.makeText(Module.this, "Nothing found", Toast.LENGTH_LONG).show();
            }

        });
    }
}
