package com.example.iapp301assignment;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Calendar;

public class StudentRecords extends AppCompatActivity {
    private EditText editTextName, editTextSurname, editTextDob, editTextPassword;
    private Button addStudent, viewStudents;
    private MyDatabaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_records);

        editTextName = findViewById(R.id.txtStudentName);
        editTextSurname = findViewById(R.id.txtStudentSurname);
        editTextPassword = findViewById(R.id.txtStudentPassword);
        editTextDob = findViewById(R.id.txtStudentDob);
        addStudent = findViewById(R.id.btnAddStudent);
        viewStudents = findViewById(R.id.btnViewStudents);
        myDb = new MyDatabaseHelper(this);

        // Disable manual input on DOB EditText and make it clickable
        editTextDob.setFocusable(false);
        editTextDob.setClickable(true);

        // Open DatePickerDialog when DOB EditText is clicked
        editTextDob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        StudentRecords.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
                                // Month is zero-based, so add 1
                                String date = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                                editTextDob.setText(date);
                            }
                        },
                        year, month, day);
                datePickerDialog.show();
            }
        });

        addStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = editTextName.getText().toString();
                String surname = editTextSurname.getText().toString();
                String dob = editTextDob.getText().toString();
                String password = editTextPassword.getText().toString();

                boolean isInserted = myDb.insertData2(name, surname, dob, password);
                if (isInserted) {
                    Toast.makeText(StudentRecords.this, "Student Data Added!", Toast.LENGTH_LONG).show();
                    editTextName.setText("");
                    editTextSurname.setText("");
                    editTextDob.setText("");
                    editTextPassword.setText("");
                } else {
                    Toast.makeText(StudentRecords.this, "Student Data Not Added", Toast.LENGTH_LONG).show();
                }
            }
        });

        viewStudents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = myDb.getAllItems2();
                if (res.getCount() == 0) {
                    Toast.makeText(StudentRecords.this, "Nothing found", Toast.LENGTH_LONG).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()) {
                    buffer.append("ID :" + res.getString(0) + "\n");
                    buffer.append("Name :" + res.getString(1) + "\n");
                    buffer.append("Surname :" + res.getString(2) + "\n");
                    buffer.append("Dob :" + res.getString(3) + "\n");
                    buffer.append("Password :" + res.getString(4) + "\n\n");
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(StudentRecords.this);
                builder.setCancelable(true);
                builder.setTitle("Students");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });
    }
}
