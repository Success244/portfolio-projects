package com.example.iapp301assignment;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ViewTask extends AppCompatActivity {
    private MyDatabaseHelper myDb;
    Button Displaytask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_task);

        Displaytask = findViewById(R.id.btnDisplayTask);
        myDb = new MyDatabaseHelper(this);

        Displaytask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res =myDb.getAllItems();
                if(res.getCount()==0)
                {
                    Toast.makeText(ViewTask.this, "Nothing found", Toast.LENGTH_LONG).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext()){
                    buffer.append("ID :"+res.getString(0)+"\n");
                    buffer.append("Name :"+res.getString(1)+"\n");
                    buffer.append("Due Date :"+res.getString(2)+"\n");
                    buffer.append("Module :"+res.getString(3)+"\n\n");
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(ViewTask.this);
                builder.setCancelable(true);
                builder.setTitle("Tasks");
                builder.setMessage(buffer.toString());
                builder.show();

            }
        });





    }}
