package com.example.iapp301assignment;

import static com.example.iapp301assignment.MyDatabaseHelper.DATABASE_NAME;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private MyDatabaseHelper myDb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText Username = (EditText) findViewById(R.id.txtUsername);
        EditText Password = (EditText) findViewById(R.id.txtPassword);
        final Spinner spinner = (Spinner) findViewById(R.id.usertype);
        Button Login = (Button) findViewById(R.id.btnLogin);
        myDb = new MyDatabaseHelper(this);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.usertype, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user = Username.getText().toString();
                String password = Password.getText().toString();

                String item = spinner.getSelectedItem().toString();
                Boolean checkStudentName = myDb.checkStudentName(user);
                Boolean checkStudentPassword = myDb.checkStudentPassword(password);
                Boolean checkInstructorName = myDb.checkInstructorName(user);
                Boolean checkInstructorPassword = myDb.checkInstructorPassword(password);
                if (checkStudentName==true &&
                        checkStudentPassword==true &&
                        item.equals("Student"))
                {
                    //  Toast.makeText(MainActivity.this, "sign in successful", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), Student.class);
                    startActivity(intent);
                }

                else if (checkInstructorName==true &&
                        checkInstructorPassword &&
                        item.equals("Instructor"))
                {
                    Intent intent = new Intent(MainActivity.this, Instructor.class);
                    startActivity(intent);
                }

                else if (Username.getText().toString().equals("Admin") &&
                        Password.getText().toString().equals("AdminPassword") &&
                        item.equals("Admin"))
                {
                    Intent intent = new Intent(MainActivity.this, Admin.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(getApplicationContext(), "Invalid Login Details, Try Again", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
};
