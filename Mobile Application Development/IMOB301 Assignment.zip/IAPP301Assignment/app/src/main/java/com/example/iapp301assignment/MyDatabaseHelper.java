package com.example.iapp301assignment;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.sql.Date;

public class MyDatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "AcademicManagement.db";


    public static final String TABLE_NAME = "TasksTable";
    public static final String TABLE_NAME2 = "StudentTable";
    public static final String TABLE_NAME3 = "ModuleTable";
    public static final String TABLE_NAME4 = "InstructorTable";

    public static final String COL_1 = "TASKID";
    public static final String COL_2 = "NAME";
    public static final String COL_3 = "DUEDATE";
    public static final String COL_4 = "MODULE";
    public static final String COL_5 = "STUDENTID";
    public static final String COL_6 = "NAME";
    public static final String COL_7 = "SURNAME";
    public static final String COL_8 = "DOB";
    public static final String COL_9 = "PASSWORD";
    public static final String COL_10 = "MODULEID";
    public static final String COL_11 = "NAME";
    public static final String COL_12 = "DURATION";
    public static final String COL_13 = "INSTRUCTORID";
    public static final String COL_14 = "NAME";
    public static final String COL_15 = "SURNAME";
    public static final String COL_16 = "PASSWORD";



    public MyDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + "(TASKID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, DUEDATE DATE, MODULE TEXT)");
        db.execSQL("create table " + TABLE_NAME2 + "(STUDENTID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, SURNAME TEXT, DOB DATE, PASSWORD TEXT)");
        db.execSQL("create table " + TABLE_NAME3 + "(MODULEID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, DURATION INTEGER)");
        db.execSQL("create table " + TABLE_NAME4 + "(INSTRUCTORID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, SURNAME TEXT, PASSWORD TEXT)");
       /* db.execSQL("ALTER TABLE " + TABLE_NAME2 + " ADD COLUMN PASSWORD TEXT");
        db.execSQL("ALTER TABLE " + TABLE_NAME4 + " ADD COLUMN PASSWORD TEXT");*/

    }



    public boolean insertData1(String name, String dueDate, String module){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2, name);
        contentValues.put(COL_3, dueDate);
        contentValues.put(COL_4, module);
        long result = db.insert(TABLE_NAME, null, contentValues);
        return result != -1;
    }
    public boolean insertData2(String name, String surname, String dob, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues1 = new ContentValues();
        contentValues1.put(COL_6, name);
        contentValues1.put(COL_7, surname);
        contentValues1.put(COL_8, dob);
        contentValues1.put(COL_9, password);
        long result = db.insert(TABLE_NAME2, null, contentValues1);
        return result != -1;
    }
    public boolean insertData3(String name, int duration){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues2 = new ContentValues();
        contentValues2.put(COL_11, name);
        contentValues2.put(COL_12, duration);
        long result = db.insert(TABLE_NAME3, null, contentValues2);
        return result != -1;
    }
    public boolean insertData4(String name, String surname, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues3 = new ContentValues();
        contentValues3.put(COL_14, name);
        contentValues3.put(COL_15, surname);
        contentValues3.put(COL_16, password);
        long result = db.insert(TABLE_NAME4, null, contentValues3);
        return result != -1;
    }

    public Cursor getAllItems(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        return cursor;
    }
    public Cursor getAllItems2(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor2 = db.rawQuery("SELECT * FROM " + TABLE_NAME2, null);
        return cursor2;
    }
    public Cursor getAllItems3(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor3 = db.rawQuery("SELECT * FROM " + TABLE_NAME3, null);
        return cursor3;
    }

    public Cursor getAllItems4(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor4 = db.rawQuery("SELECT * FROM " + TABLE_NAME4, null);
        return cursor4;
    }

    public Boolean checkStudentName(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME2 + " WHERE name = ?", new String[] {name});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }
    public Boolean checkStudentPassword(String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME2 + " WHERE password = ?", new String[] {password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }
    public Boolean checkInstructorName(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME4 + " WHERE name = ?", new String[] {name});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }
    public Boolean checkInstructorPassword(String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME4 + " WHERE password = ?", new String[] {password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME2);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME3);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME4);
        onCreate(db);
    }
}
