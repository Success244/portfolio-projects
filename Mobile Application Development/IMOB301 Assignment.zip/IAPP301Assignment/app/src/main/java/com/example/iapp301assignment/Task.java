package com.example.iapp301assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Calendar;

public class Task extends AppCompatActivity {
    private EditText editTextName, editTextDueDate, editTextModule;
    private Button createTask;
    private MyDatabaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task);

        editTextName = findViewById(R.id.txtname);
        editTextDueDate = findViewById(R.id.txtduedate);
        editTextModule = findViewById(R.id.txtmodule);
        createTask = findViewById(R.id.btnCreateTask);
        myDb = new MyDatabaseHelper(this);

        // Set up DatePicker for the due date field
        editTextDueDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        Task.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
                                // Format as yyyy-MM-dd
                                String date = String.format("%04d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay);
                                editTextDueDate.setText(date);
                            }
                        },
                        year, month, day);
                datePickerDialog.show();
            }
        });

        createTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = editTextName.getText().toString();
                String duedate = editTextDueDate.getText().toString();
                String module = editTextModule.getText().toString();

                boolean isInserted = myDb.insertData1(name, duedate, module);
                if (isInserted) {
                    Toast.makeText(Task.this, "Task Added!", Toast.LENGTH_LONG).show();
                    editTextName.setText("");
                    editTextDueDate.setText("");
                    editTextModule.setText("");
                } else {
                    Toast.makeText(Task.this, "Task Not Added", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
